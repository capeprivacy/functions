
def cape_handler(n):
    data = n.decode("utf-8")
    return data
